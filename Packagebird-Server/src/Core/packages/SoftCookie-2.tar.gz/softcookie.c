#include<stdio.h>
int main(int arc, char *argv[]) {
    printf("I'm a soft-cookie");
    return 0;
}